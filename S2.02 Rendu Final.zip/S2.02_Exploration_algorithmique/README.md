# S2.02
Projet fait sur Eclipse

## Execution

Dans un terminal :
- cd S2.02_Exploration_algorithmique
- java -jar main-executable.jar .\src\test\France.csv

